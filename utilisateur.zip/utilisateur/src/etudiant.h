#include <gtk/gtk.h>


typedef struct
{
        char cin;
	char nom[20];
        char email[20];
        char niv;
} etudiant;
  

void afficher_etudiants(GtkWidget *liste);
void afficher_etudiants1(GtkWidget *liste);
void afficher_etudiants2(GtkWidget *liste);

