#include <gtk/gtk.h>


void
on_bellil1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bellil11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bellil12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Confermet_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
