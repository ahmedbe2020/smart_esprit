#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "etudiant.h"




void
on_bellil1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ahmed2();
gtk_widget_show (window);
}


void
on_bellil2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ahmed4();
gtk_widget_show (window);
}


void
on_bellil3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ahmed3();
gtk_widget_show (window);


}


void
on_bellil4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
 button=create_ahmed4();
gtk_widget_show (window);
FILE *f=NULL;
GtkWidget *nom,*prenom,*email,*cin,*mot,*cmot;
char chnom[20];
char chprenom[20];
char chemail[20];
int icin;
char chmot[20];
char chcmot[20];
nom = lookup_widget (button, "entry1");
prenom = lookup_widget (button, "entry2");
email = lookup_widget (button, "entry3");
cin = lookup_widget (button, "entry4");
mot=lookup_widget (button, "entry5");
cmot = lookup_widget (button, "entry6");

strcpy(chnom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(chprenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(chemail, gtk_entry_get_text(GTK_ENTRY(email)));
icin=gtk_entry_get_text(GTK_ENTRY(cin));
strcpy(chmot, gtk_entry_get_text(GTK_ENTRY(mot)));
strcpy(chcmot, gtk_entry_get_text(GTK_ENTRY(cmot)));

//ouvrir le fichier 
f=fopen("administrateur.txt","a+");
if (f!=NULL)
{
//ecrire dans le fichier
fprintf (f,"%s \n %s \n %s \n %d \n %s \n \n\n\n",chnom,chprenom,chemail,icin,chmot);
fclose(f);
}
else
printf ("\n Not found");

}


void
on_bellil5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_ahmed5();
gtk_widget_show (window);
}


void
on_bellil6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *treeview1;
GtkWidget *button6;
button6=create_ahmed6();
gtk_widget_show (button6);
treeview1=lookup_widget(button6,"treeview1");
afficher_etudiants(treeview1);
}


void
on_bellil7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;







GtkWidget *button1;
button1=create_ahmed7();
gtk_widget_show(button1);


afficher_etudiants(treeview1);
}


void
on_bellil8_clicked                     (GtkButton       *button1,
                                        gpointer         user_data)
{


button1=create_windowmod();
gtk_widget_show(button1);
}


void
on_bellil9_clicked                     (GtkButton       *button1,
                                        gpointer         user_data)
{

                                    



button1=create_windowsup();
gtk_widget_show(button1);
}


void
on_bellil10_clicked                    (GtkButton       *button1,
                                        gpointer         user_data)
{

button1=create_windowrech();
gtk_widget_show(button1);


}


void
on_bellil11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *window;
GtkWidget *treeview1;


FILE* f1;
FILE* f2;
int n1=0,n2=0,n3=0,n4=0,n5=0;
char a[10],b[10],c[10],d[10];
int x;
remove("sta.txt");
f1 =fopen("etudiants.txt","r");
f2=fopen("sta.txt","a+");


  
        while (fscanf(f1,"%s %s %s %s",a,b,c,d)!=EOF)
        {
x=atoi(d);
            
                if (x==1)
                {n1=n1+1;
				}
else  if (x==2)
                {n2=n2+1;
			
                  }
else  if (x==3)
                {n3=n3+1;
				
                  }
else  if (x==4)
                {n4=n4+1;
				
                 }
else   if (x==5)
                {n5=n5+1;
				
                  }


       }
       
     fprintf(f2,"niveau1 %d \n",n1);
      fprintf(f2,"niveau2 %d \n",n2);
       fprintf(f2,"niveau3 %d \n",n3);
        fprintf(f2,"niveau4 %d \n",n4);
         fprintf(f2,"niveau5 %d \n",n5);
        
    fclose(f1);
    fclose(f2);
GtkWidget *button6;
button6=create_ahmed6();
gtk_widget_show (button6);
treeview1=lookup_widget(button6,"treeview1");
afficher_etudiants2(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* cin;
	gchar* nom;
	gchar* email;
	gchar* niv;
	etudiant p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview1);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&cin, 1 ,&nom, 2 ,&email, 3 ,&niv ,-1);
	strcpy(p.cin,cin);
	strcpy(p.nom,nom);
	strcpy(p.email,email);
	strcpy(p.niv,niv);
        afficher_etudiants(treeview1);
	}
}


void
on_bellil12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *cin,*nom,*email,*niv;
GtkWidget *window;
GtkWidget *treeview1;


char a[20];
char b[20];
char c[20];
char d[20];
char x[20],y[20],z[20],w[20];
int trouve;
cin = lookup_widget (button, "entry10");
nom = lookup_widget (button, "entry11");
email= lookup_widget (button, "entry12");
niv= lookup_widget (button, "entry13");
strcpy(a, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(b, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(c, gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(d, gtk_entry_get_text(GTK_ENTRY(niv)));




//ajouter :
	FILE *f;
	f=fopen("etudiants.txt","a");
	if (f!=NULL){
	strcpy(x,a);
	strcpy(y,b);
	strcpy(z,c);
	strcpy(w,d);
	fprintf(f,"%s %s %s %s\n",x,y,z,w);
	
	}
fclose(f);
GtkWidget *button6;
button6=create_ahmed6();
gtk_widget_show (button6);
treeview1=lookup_widget(button6,"treeview1");
afficher_etudiants(treeview1);
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(button);
FILE* f;
FILE* f2;



gtk_widget_show(button);

GtkWidget *treeview1;


GtkWidget *cin;

char cin1[20],a[10],b[10],c[10],d[10];
f=fopen("etudiants.txt","r");
f2=fopen("tmp.txt","w");
cin=lookup_widget(button,"entry14");

strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));



f=fopen("etudiants.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(cin1,a)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
    remove("etudiants.txt");
    rename("tmp.txt","etudiants.txt");

button=create_ahmed6();
gtk_widget_show (button);
treeview1=lookup_widget(button,"treeview1");
afficher_etudiants(treeview1);




}


void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(button);
FILE* f;
FILE* f2;
FILE* f3;



gtk_widget_show(button);

GtkWidget *treeview1;


GtkWidget *cin;

char cin1[20],a[10],b[10],c[10],d[10];
 remove("rech.txt");
f=fopen("etudiants.txt","r");
f2=fopen("rech.txt","w");
f3=fopen("eur.txt","w");
cin=lookup_widget(button,"entry15");

strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));





  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(cin1,a)!=0)
                
		    fprintf(f3,"%s %s %s %s\n",a,b,c,d);
else fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
 fclose(f3);
 

button=create_ahmed6();
gtk_widget_show (button);
treeview1=lookup_widget(button,"treeview1");
afficher_etudiants1(treeview1);


}


void
on_Confermet_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(button);



GtkWidget *treeview1;

GtkWidget *cin;

GtkWidget *cin1;
GtkWidget *e2;
GtkWidget *ni;
GtkWidget *n2;

char cin2[20],a[10],b[10],c[10],d[10],cin3[20],n3[20],e3[20],ni3[20];

cin=lookup_widget(button,"cin1");


strcpy(cin2,gtk_entry_get_text(GTK_ENTRY(cin)));




cin1=lookup_widget(button,"cin2");
n2=lookup_widget(button,"n2");
e2=lookup_widget(button,"e2");
ni=lookup_widget(button,"ni");
strcpy(cin3,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(n3,gtk_entry_get_text(GTK_ENTRY(n2)));
strcpy(e3,gtk_entry_get_text(GTK_ENTRY(e2)));
strcpy(ni3,gtk_entry_get_text(GTK_ENTRY(ni)));




FILE* f=NULL;
FILE* f2;

f=fopen("etudiants.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(cin2,a)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
                   else
                   fprintf(f2,"%s %s %s %s\n",cin3,n3,e3,ni3);}
        
    fclose(f);
    fclose(f2);
    remove("etudiants.txt");
    rename("tmp.txt","etudiants.txt");

button=create_ahmed6();
gtk_widget_show (button);
treeview1=lookup_widget(button,"treeview1");
afficher_etudiants(treeview1);


}

