#include<stdio.h>
#include<etudiant.h>

#include <gtk/gtk.h>


enum
{
	ECIN,
	ENOM,
	EEMAIL,
	ENIV,
	COLUMNS
};

////////////////////////////////////////////
void afficher_etudiants(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char cin[50];
	char nom[50];
	char email[100];
	char niv[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		CIN",renderer,"text",ECIN, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Nom et prénom",renderer,"text",ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" E-mail",renderer,"text",EEMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 	Niveau",renderer,"text",ENIV, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("etudiants.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("etudiants.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",cin,nom,email,niv)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,ECIN,cin,ENOM,nom,EEMAIL,email,ENIV,niv, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}
	



void afficher_etudiants1(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char cin[50];
	char nom[50];
	char email[100];
	char niv[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		CIN",renderer,"text",ECIN, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Nom et prénom",renderer,"text",ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" E-mail",renderer,"text",EEMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 	Niveau",renderer,"text",ENIV, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("rech.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("rech.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",cin,nom,email,niv)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,ECIN,cin,ENOM,nom,EEMAIL,email,ENIV,niv, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}




void afficher_etudiants2(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char cin[50];
	char nom[50];
	char email[100];
	char niv[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		niveau",renderer,"text",ECIN, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		nombre etudiants",renderer,"text",ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	

	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("sta.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("sta.txt","a+");
		while(fscanf(f,"%s %s\n",cin,nom)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,ECIN,cin,ENOM,nom,EEMAIL,email,ENIV,niv, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}
	


